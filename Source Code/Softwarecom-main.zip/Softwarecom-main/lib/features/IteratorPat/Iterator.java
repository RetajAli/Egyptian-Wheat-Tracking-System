package features.IteratorPat;

public interface Iterator {
    boolean hasNext();
    String next();
}
