package features.IteratorPat;

public class TransportMethodIterator implements Iterator{
    private String[] methods;
    private int position = 0;

    public TransportMethodIterator(String[] methods) {
        this.methods = methods;
    }

    @Override
    public boolean hasNext() {
        return position < methods.length && methods[position] != null;
    }

    @Override
    public String next() {
        if (!hasNext()) throw new java.util.NoSuchElementException("No more transport methods.");
        return methods[position++];
    }
}
