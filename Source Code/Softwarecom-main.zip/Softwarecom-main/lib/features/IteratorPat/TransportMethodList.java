package features.IteratorPat;

public class TransportMethodList implements MethodCollection{
    private String[] methods = new String[3];
    private int count = 0;

    public void addMethod(String method) {
        if (count < methods.length) {
            methods[count++] = method;
        } else {
            System.out.println("Method list is full.");
        }
    }

    @Override
    public Iterator createIterator() {
        return new TransportMethodIterator(methods);
    }
}
