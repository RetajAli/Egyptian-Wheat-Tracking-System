package features.IteratorPat;

public interface MethodCollection {
    Iterator createIterator();
}
