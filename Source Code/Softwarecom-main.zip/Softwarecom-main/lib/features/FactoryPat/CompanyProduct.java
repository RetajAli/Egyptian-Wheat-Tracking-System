package features.FactoryPat;

public abstract class CompanyProduct {
    String productName;
    String productionDate;
    String productExperiDate;
    double productWeight;
    int productClassification;

    public CompanyProduct(String productName, String productionDate, String productExperiDate, double productWeight, int productClassification) {
        this.productName = productName;
        this.productionDate = productionDate;
        this.productExperiDate = productExperiDate;
        this.productWeight = productWeight;
        this.productClassification = productClassification;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getManifuctionDate() {
        return productionDate;
    }

    public void setManifuctionDate(String manifuctionDate) {
        this.productionDate = productionDate;
    }

    public String getProductExperiDate() {
        return productExperiDate;
    }

    public void setProductExperiDate(String productExperiDate) {
        this.productExperiDate = productExperiDate;
    }

    public double getProductWeight() {
        return productWeight;
    }

    public void setProductWeight(double productWeight) {
        this.productWeight = productWeight;
    }

    public int getProductClassification() {
        return productClassification;
    }

    public void setProductClassification(int productClassification) {
        this.productClassification = productClassification;
    }
}
