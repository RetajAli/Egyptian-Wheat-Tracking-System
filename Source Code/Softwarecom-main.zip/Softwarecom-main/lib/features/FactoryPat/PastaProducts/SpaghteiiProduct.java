package features.FactoryPat.PastaProducts;

import features.FactoryPat.CompanyProduct;

public class SpaghteiiProduct extends CompanyProduct {
    public SpaghteiiProduct(String productName, String productionDate, String productExperiDate, double productWeight, int productClassification) {
        super(productName, productionDate, productExperiDate, productWeight, productClassification);
    }
}
