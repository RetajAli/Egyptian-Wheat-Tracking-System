package features.FactoryPat.PastaProducts;

import features.FactoryPat.CompanyProduct;

public class PennaProduct extends CompanyProduct {
    public PennaProduct(String productName, String productionDate, String productExperiDate, double productWeight, int productClassification) {
        super(productName, productionDate, productExperiDate, productWeight, productClassification);
    }
}
