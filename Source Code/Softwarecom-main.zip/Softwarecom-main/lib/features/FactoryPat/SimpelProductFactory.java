package features.FactoryPat;

import features.FactoryPat.BreadProducts.BreadProduct;
import features.FactoryPat.BreadProducts.LocalBreadProduct;
import features.FactoryPat.PastaProducts.PennaProduct;
import features.FactoryPat.PastaProducts.SpaghteiiProduct;

public class SimpelProductFactory {

    String productName;
    String productionDate;
    String productExperiDate;
    double productWeight;
    int productClassification;

    public CompanyProduct creatproduct(String productType){
        CompanyProduct product =null;

        if (productType.equalsIgnoreCase("Bread Product"))
            product = new BreadProduct(productName,productionDate,productExperiDate,productWeight,productClassification);

        else if (productType.equalsIgnoreCase("Local Bread Product"))
            product = new LocalBreadProduct(productName,productionDate,productExperiDate,productWeight,productClassification);

        else if (productType.equalsIgnoreCase("Penna Product"))
            product = new PennaProduct(productName,productionDate,productExperiDate,productWeight,productClassification);

        else if (productType.equalsIgnoreCase("Spaghteii Product"))
            product = new SpaghteiiProduct(productName,productionDate,productExperiDate,productWeight,productClassification);


        return product;
    }
}
