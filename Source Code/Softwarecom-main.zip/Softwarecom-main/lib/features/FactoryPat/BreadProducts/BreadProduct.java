package features.FactoryPat.BreadProducts;

import features.FactoryPat.CompanyProduct;

public class BreadProduct extends CompanyProduct {
    public BreadProduct(String productName, String productionDate, String productExperiDate, double productWeight, int productClassification) {
        super(productName, productionDate, productExperiDate, productWeight, productClassification);
    }

}
