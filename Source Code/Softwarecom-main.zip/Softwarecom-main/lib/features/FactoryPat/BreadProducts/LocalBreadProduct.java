package features.FactoryPat.BreadProducts;

import features.FactoryPat.CompanyProduct;

public class LocalBreadProduct extends CompanyProduct {
    public LocalBreadProduct(String productName, String productionDate, String productExperiDate, double productWeight, int productClassification) {
        super(productName, productionDate, productExperiDate, productWeight, productClassification);
    }

}
