package features.auth;

import java.util.HashMap;
import java.util.Map;

public class Login {

    private String username;
    private String password;
    private String role;

    private static final Map<String, String> users = new HashMap<>();
    private static final Map<String, String> roles = new HashMap<>();

    static {
        users.put("admin", "admin123");
        users.put("distribution", "dist123");
        users.put("silo", "silo123");
        users.put("mill", "mill123");
        users.put("transport", "trans123");
        users.put("factory", "factory123");
        users.put("bakery", "bakery123");

        roles.put("admin", "System Admin");
        roles.put("distribution", "Distribution Company");
        roles.put("silo", "Silo Company");
        roles.put("mill", "Mills Company");
        roles.put("transport", "Transport Company");
        roles.put("factory", "Factory Company");
        roles.put("bakery", "Bakery Company");
    }

    public Login(String username, String password) {
        this.username = username;
        this.password = password;
    }

    public boolean authenticate() {
        if (username == null || password == null) {
            return false;
        }

        String savedPassword = users.get(username.toLowerCase());

        if (savedPassword != null && savedPassword.equals(password)) {
            role = roles.get(username.toLowerCase());
            return true;
        }

        return false;
    }

    public void showLoginResult() {
        if (authenticate()) {
            System.out.println("=================================");
            System.out.println("Login Successful");
            System.out.println("Welcome to Egyptian Wheat Tracking System");
            System.out.println("User Role: " + role);
            System.out.println("=================================");
        } else {
            System.out.println("Login Failed: Invalid username or password");
        }
    }

    public String getRole() {
        return role;
    }
}