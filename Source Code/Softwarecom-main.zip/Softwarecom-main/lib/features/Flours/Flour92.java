package features.Flours;

public class Flour92 extends FlourTypes {
 String herbs= "thyme";
    protected void checkWheat() {
        System.out.println("Checking high quality wheat for Flour 92%");
    }

    protected void grindWheat() {
        System.out.println("Grinding wheat finely for Flour 92%");
    }

    protected void packageFlour() {
        System.out.println("Packaging Flour 92%");
    }
    public void addHerbs(String herbs) {
        System.out.println("Adding herbs: " + herbs);
    }
}