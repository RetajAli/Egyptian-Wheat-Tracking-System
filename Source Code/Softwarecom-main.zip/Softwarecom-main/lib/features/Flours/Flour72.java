package features.Flours;

public class Flour72 extends FlourTypes {
	String herbs= "Garlic powder";
    protected void checkWheat() {
        System.out.println("Checking standard wheat for Flour 72%");
    }

    protected void grindWheat() {
        System.out.println("Grinding wheat for Flour 72%");
    }

    protected void packageFlour() {
        System.out.println("Packaging Flour 72%");
    }
    public void addHerbs(String herbs) {
        System.out.println("Adding herbs: " + herbs);
    }
}