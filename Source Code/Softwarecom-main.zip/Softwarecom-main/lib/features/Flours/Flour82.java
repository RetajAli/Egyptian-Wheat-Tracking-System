package features.Flours;

public class Flour82 extends FlourTypes {
	String herbs= "rose mary";
    protected void checkWheat() {
        System.out.println("Checking medium quality wheat for Flour 82%");
    }

    protected void grindWheat() {
        System.out.println("Grinding wheat for Flour 82%");
    }

    protected void packageFlour() {
        System.out.println("Packaging Flour 82%");
    }
    public void addHerbs(String herbs) {
        System.out.println("Adding herbs: " + herbs);
    }
}