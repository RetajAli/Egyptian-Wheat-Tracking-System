package features.Flours;

public abstract class FlourTypes {

    // Template Method
    public void processFlour() {
    	
        checkWheat();
        grindWheat();
        packageFlour();
        
    }

    protected abstract void checkWheat();
    protected abstract void grindWheat();
    protected abstract void packageFlour();
}
