package features.Observers;


public interface TransportSubject {
    void registerObserver(Observers o);
    void removeObserver(Observers o);
    void notifyObservers();
}
