package features.Observers;

public interface Observers {
    void update(String data);

}
