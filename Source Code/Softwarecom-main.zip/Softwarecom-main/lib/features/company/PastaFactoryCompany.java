package features.company;

import features.FactoryPat.CompanyProduct;

public class PastaFactoryCompany extends Company{
    String pastaTypes;
    public CompanyProduct product;

    public PastaFactoryCompany(String companyName, String companyAddress, String companyProduct, double incomeWeight, double outWeight, String pastaTypes, CompanyProduct product) {
        super(companyName, companyAddress, companyProduct, incomeWeight, outWeight);
        this.pastaTypes = pastaTypes;
        this.product = product;
    }

    public String getPastaTypes() {
        return pastaTypes;
    }

    public void setPastaTypes(String pastaTypes) {
        this.pastaTypes = pastaTypes;
    }

    public CompanyProduct getProduct() {
        return product;
    }

    public void setProduct(CompanyProduct product) {
        this.product = product;
    }

}
