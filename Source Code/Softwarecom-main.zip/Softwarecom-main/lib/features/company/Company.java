package features.company;

public class Company {
    private String companyName;
    private String companyAddress;
    private String CompanyProduct;
    private double incomeWeight;
    private double outWeight;

    public Company(String companyName, String companyAddress, String companyProduct, double incomeWeight, double outWeight) {
        this.companyName = companyName;
        this.companyAddress = companyAddress;
        CompanyProduct = companyProduct;
        this.incomeWeight = incomeWeight;
        this.outWeight = outWeight;
    }

    public String getCompanyName() {
        return companyName;
    }
    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getCompanyAddress() {
        return companyAddress;
    }
    public void setCompanyAddress(String companyAddress) {
        this.companyAddress = companyAddress;
    }

    public String getCompanyProduct() {
        return CompanyProduct;
    }

    public void setCompanyProduct(String companyProduct) {
        CompanyProduct = companyProduct;
    }

    public double getOutWeight() {
        return outWeight;
    }

    public double getIncomeWeight() {
        return incomeWeight;
    }

    public void setIncomeWeight(double incomeWeight) {
        this.incomeWeight = incomeWeight;
    }


    public void setOutWeight(double outWeight) {
        this.outWeight = outWeight;
    }


}
