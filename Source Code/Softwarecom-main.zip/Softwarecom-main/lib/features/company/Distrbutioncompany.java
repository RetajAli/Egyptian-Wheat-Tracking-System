package features.company;

import features.Observers.Observers;
import java.util.ArrayList;
import singelton.CheckWheat;

public class Distrbutioncompany extends Company implements Observers {
    double totalWheat;
    ArrayList<String> countries;
    private CheckWheat checkWheatInstance;

    public Distrbutioncompany(String companyName, String companyAddress, String companyProduct, double incomeWeight, double outWeight, double totalWheat, ArrayList<String> countries) {
        super(companyName, companyAddress, companyProduct, incomeWeight, outWeight);
        this.totalWheat = totalWheat;
        this.countries = countries;
        this.checkWheatInstance = CheckWheat.getInstance();
    }

    public double getTotalWheat() {
        return totalWheat;
    }

    public void setTotalWheat(double totalWheat) {
        this.totalWheat = totalWheat;
    }

    public ArrayList<String> getCountries() {
        return countries;
    }

    public void setCountries(ArrayList<String> countries) {
        this.countries = countries;
    }

    public void AssingnToPlace(String country, double totalWheat) {
        // Function to distribute the wheat to a specific country
        if (country == null || country.isEmpty()) {
            System.out.println("[ERROR] Invalid country name provided");
            return;
        }

        if (totalWheat <= 0) {
            System.out.println("[ERROR] Wheat amount must be greater than 0");
            return;
        }

        if (totalWheat > this.totalWheat) {
            System.out.println("[ERROR] Not enough wheat available. Available: " + this.totalWheat + " kg, Requested: " + totalWheat + " kg");
            return;
        }

        if (!countries.contains(country)) {
            countries.add(country);
            System.out.println("[INFO] New country added to distribution list: " + country);
        }

        // Deduct the assigned wheat from total
        this.totalWheat -= totalWheat;

        System.out.println("=== Wheat Distribution ===");
        System.out.println("Country: " + country);
        System.out.println("Wheat Amount Assigned: " + totalWheat + " kg");
        System.out.println("Remaining Wheat: " + this.totalWheat + " kg");
        System.out.println("==========================");
    }

    public void update(String data) {
        System.out.println("Wheat received: " + data);
    }

}
