package features.company;

import features.Observers.Observers;

import java.util.ArrayList;

public class BakeryCompany extends Company implements Observers {
    ArrayList<String> Products;

    public BakeryCompany(String companyName, String companyAddress, String companyProduct, double incomeWeight, double outWeight, ArrayList<String> products) {
        super(companyName, companyAddress, companyProduct, incomeWeight, outWeight);
        Products = products;
    }

    public ArrayList<String> getProducts() {
        return Products;
    }

    public void setProducts(ArrayList<String> products) {
        Products = products;
    }

    public void update(String data) {
        System.out.println("Bakery received: " + data);
    }
}
