package features.company;

import features.IteratorPat.Iterator;
import features.IteratorPat.TransportMethodList;
import features.Observers.Observers;
import features.Observers.TransportSubject;
import java.util.ArrayList;

public class TransportCompany extends Company implements TransportSubject {
    private TransportMethodList methodList;   // replaces the single String method
    double WeightTransport;
    String LocationFrom, LocatonTo;
    String EstimatedTimeTransport;
    private ArrayList<Observers> observers; // List to hold all observers

    public TransportCompany(String companyName, String companyAddress, String companyProduct,
                            double incomeWeight, double outWeight,
                            double weightTransport, String locationFrom,
                            String locatonTo, String estimatedTimeTransport) {
        super(companyName, companyAddress, companyProduct, incomeWeight, outWeight);

        // Initialize observers list
        this.observers = new ArrayList<>();

        // Initialize and populate the method list
        this.methodList = new TransportMethodList();
        methodList.addMethod("truck");
        methodList.addMethod("ship");
        methodList.addMethod("train");

        WeightTransport = weightTransport;
        LocationFrom = locationFrom;
        LocatonTo = locatonTo;
        EstimatedTimeTransport = estimatedTimeTransport;
    }

    // Iterate and print all transport methods
    public void printAllMethods() {
        Iterator iterator = methodList.createIterator();
        System.out.println("Available Transport Methods:");
        while (iterator.hasNext()) {
            System.out.println(" - " + iterator.next());
        }
    }

    public Iterator getMethodIterator() {
        return methodList.createIterator();
    }

    public double getWeightTransport() {
        return WeightTransport;
    }

    public void setWeightTransport(double weightTransport) {
        WeightTransport = weightTransport;
    }

    public String getLocationFrom() {
        return LocationFrom;
    }

    public void setLocationFrom(String locationFrom) {
        LocationFrom = locationFrom;
    }

    public String getLocatonTo() {
        return LocatonTo;
    }

    public void setLocatonTo(String locatonTo) {
        LocatonTo = locatonTo;
    }

    public String getEstimatedTimeTransport() {
        return EstimatedTimeTransport;
    }

    public void setEstimatedTimeTransport(String estimatedTimeTransport) {
        EstimatedTimeTransport = estimatedTimeTransport;
    }


    @Override
    public void registerObserver(Observers o) {
        if (!observers.contains(o)) {
            observers.add(o);
            System.out.println("Observer registered successfully for Transport Company: " + getCompanyName());
        }
    }

    @Override
    public void removeObserver(Observers o) {
        if (observers.remove(o)) {
            System.out.println("Observer removed successfully from Transport Company: " + getCompanyName());
        }
    }

    @Override
    public void notifyObservers() {
        String transportMessage = "Transport notification - From: " + LocationFrom + ", To: " + LocatonTo + 
                                  ", Weight: " + WeightTransport + " kg, Estimated Time: " + EstimatedTimeTransport;
        for (Observers observer : observers) {
            observer.update(transportMessage);
        }
    }
}
