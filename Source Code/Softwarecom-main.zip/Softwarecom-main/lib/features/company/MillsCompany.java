package features.company;

import features.Observers.Observers;

public class MillsCompany extends Company implements Observers {
    private double WeightAfterGrilling;
    private String CompanyProduct ;

    public MillsCompany(String companyName, String companyAddress, String companyProduct, double incomeWeight, double outWeight, double weightAfterGrilling, String companyProduct1) {
        super(companyName, companyAddress, companyProduct, incomeWeight, outWeight);
        WeightAfterGrilling = weightAfterGrilling;
        CompanyProduct = companyProduct1;
    }

    public void setWeightAfterGrilling(double weightAfterGrilling) {
        WeightAfterGrilling = weightAfterGrilling;
    }


    public double getWeightAfterGrilling() {
        return WeightAfterGrilling;
    }

    @Override
    public String getCompanyProduct() {
        return CompanyProduct;
    }

    @Override
    public void setCompanyProduct(String companyProduct) {
        CompanyProduct = companyProduct;
    }

    public void checkWeight (double incomeWeight, double outWeight){
        if (outWeight == incomeWeight){
            System.out.println("weight is correct ");
        }else
            System.out.println("weight is not correct ");
    }

    public void update(String data) {
        System.out.println("wheat received: " + data);
    }


}
