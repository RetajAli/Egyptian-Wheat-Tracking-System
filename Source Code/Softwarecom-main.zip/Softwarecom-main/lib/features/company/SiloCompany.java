package features.company;

import features.Observers.Observers;

public class SiloCompany extends Company implements Observers {
    double Storetime ;

    public SiloCompany(String companyName, String companyAddress, String companyProduct, double incomeWeight, double outWeight, double storetime) {
        super(companyName, companyAddress, companyProduct, incomeWeight, outWeight);
        Storetime = storetime;
    }
    public void update(String data) {
        System.out.println("whaet received: " + data);
    }

}
