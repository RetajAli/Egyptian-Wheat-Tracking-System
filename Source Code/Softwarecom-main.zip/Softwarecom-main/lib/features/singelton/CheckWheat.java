package singelton;
public class CheckWheat {

    private static CheckWheat instance;

    // Thresholds
    private static final double MIN_WEIGHT = 10.0;
    private static final double MAX_WEIGHT = 1000.0;
    private static final double FLOUR_YIELD_RATE = 0.75; // 75% yield from wheat to flour

    // Results stored after check
    private double acceptedWeight;
    private double rejectedWeight;
    private double flourYield;
    private double weightLossPercentage;
    private int classificationScore;
    private String qualityGrade;

    // Private constructor - Singleton
    private CheckWheat() {
        this.acceptedWeight = 0;
        this.rejectedWeight = 0;
        this.flourYield = 0;
        this.weightLossPercentage = 0;
        this.classificationScore = 0;
        this.qualityGrade = "Unclassified";
    }

     // ─────────────────────────────────────────────
    // GETTERS
    // ─────────────────────────────────────────────
    public double getAcceptedWeight()      { return acceptedWeight; }
    public double getRejectedWeight()      { return rejectedWeight; }
    public double getFlourYield()          { return flourYield; }
    public double getWeightLossPercentage(){ return weightLossPercentage; }
    public int getClassificationScore()    { return classificationScore; }
    public String getQualityGrade()        { return qualityGrade; }

    
    // Singleton getInstance
    public static CheckWheat getInstance() {
        if (instance == null) {
            instance = new CheckWheat();
        }
        return instance;
    }

    // ─────────────────────────────────────────────
    // MAIN CHECK METHOD - takes data from Distribution
    // ─────────────────────────────────────────────
    public void checkWheat(double totalWheat) {

        System.out.println("=== CheckWheat Singleton ===");
        System.out.println("Total Wheat Received from Distribution: " + totalWheat + " kg");

        // 1. Verify weight is within valid range
        verifyWeight(totalWheat);

        // 2. Classify quality grade
        classifyQuality(totalWheat);

        // 3. Calculate accepted vs rejected
        calculateAcceptedRejected(totalWheat);

        // 4. Calculate flour yield
        calculateFlourYield();

        // 5. Calculate weight loss percentage
        calculateWeightLoss(totalWheat);

        // 6. Print full report
        printReport();
    }

    // ─────────────────────────────────────────────
    // VERIFY WEIGHT
    // ─────────────────────────────────────────────
    private void verifyWeight(double totalWheat) {
        if (totalWheat < MIN_WEIGHT) {
            System.out.println("[WARNING] Wheat weight is BELOW minimum threshold (" + MIN_WEIGHT + " kg).");
        } else if (totalWheat > MAX_WEIGHT) {
            System.out.println("[WARNING] Wheat weight EXCEEDS maximum threshold (" + MAX_WEIGHT + " kg).");
        } else {
            System.out.println("[OK] Wheat weight is within valid range.");
        }
    }

    // ─────────────────────────────────────────────
    // QUALITY CLASSIFICATION
    // ─────────────────────────────────────────────
    private void classifyQuality(double totalWheat) {
        if (totalWheat >= 700) {
            classificationScore = 100;
            qualityGrade = "A - Premium";
        } else if (totalWheat >= 400) {
            classificationScore = 75;
            qualityGrade = "B - Standard";
        } else if (totalWheat >= 100) {
            classificationScore = 50;
            qualityGrade = "C - Low Grade";
        } else {
            classificationScore = 20;
            qualityGrade = "D - Rejected";
        }
        System.out.println("[QUALITY] Grade: " + qualityGrade + " | Score: " + classificationScore + "/100");
    }

    // ─────────────────────────────────────────────
    // ACCEPTED VS REJECTED WEIGHT
    // ─────────────────────────────────────────────
    private void calculateAcceptedRejected(double totalWheat) {
        if (qualityGrade.startsWith("D")) {
            acceptedWeight = 0;
            rejectedWeight = totalWheat;
        } else {
            // Accept percentage based on grade
            double acceptRate = classificationScore / 100.0;
            acceptedWeight = totalWheat * acceptRate;
            rejectedWeight = totalWheat - acceptedWeight;
        }
    }

    // ─────────────────────────────────────────────
    // FLOUR YIELD CALCULATION
    // ─────────────────────────────────────────────
    private void calculateFlourYield() {
        flourYield = acceptedWeight * FLOUR_YIELD_RATE;
    }

    // ─────────────────────────────────────────────
    // WEIGHT LOSS PERCENTAGE
    // ─────────────────────────────────────────────
    private void calculateWeightLoss(double totalWheat) {
        if (totalWheat > 0) {
            weightLossPercentage = ((totalWheat - flourYield) / totalWheat) * 100;
        } else {
            weightLossPercentage = 0;
        }
    }

    // ─────────────────────────────────────────────
    // PRINT FULL REPORT
    // ─────────────────────────────────────────────
    private void printReport() {
        System.out.println("\n====== WHEAT CHECK REPORT ======");
        System.out.printf("Quality Grade       : %s%n", qualityGrade);
        System.out.printf("Classification Score: %d / 100%n", classificationScore);
        System.out.printf("Accepted Weight     : %.2f kg%n", acceptedWeight);
        System.out.printf("Rejected Weight     : %.2f kg%n", rejectedWeight);
        System.out.printf("Flour Yield         : %.2f kg%n", flourYield);
        System.out.printf("Weight Loss         : %.2f%%%n", weightLossPercentage);
        System.out.println("================================\n");
    }
}