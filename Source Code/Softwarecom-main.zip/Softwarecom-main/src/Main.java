import features.auth.Login;
import features.company.*;
import features.FactoryPat.SimpelProductFactory;
import features.FactoryPat.CompanyProduct;
import features.Flours.*;
import features.IteratorPat.Iterator;
import features.Observers.Observers;
import singelton.CheckWheat;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) throws Exception {
        boolean isLoggedIn = false;
        String userRole = "";

        System.out.println("    EGYPTIAN WHEAT TRACKING SYSTEM - MAIN DASHBOARD        ");

        // 1. LOGIN SECTION
        while (!isLoggedIn) {
            System.out.println("\n--- LOGIN SECTION ---");
            System.out.print("Enter your username: ");
            String username = scanner.nextLine();
            System.out.print("Enter your password: ");
            String password = scanner.nextLine();

            Login login = new Login(username, password);
            if (login.authenticate()) {
                isLoggedIn = true;
                userRole = login.getRole();
                System.out.println("\n=================================");
                System.out.println("Login Successful");
                System.out.println("Welcome to Egyptian Wheat Tracking System");
                System.out.println("User Role: " + userRole);
                System.out.println("=================================\n");
            } else {
                System.out.println(" Login Failed: Invalid username or password\n");
            }
        }

        // 2. MAIN MENU
        boolean running = true;
        while (running) {

            System.out.println("          MAIN MENU - " + userRole + "              ");
            System.out.println(" 1. Company Management                          ");
            System.out.println(" 2. Factory Pattern - Create Products           ");
            System.out.println(" 3. Iterator Pattern - Transport Methods        ");
            System.out.println(" 4. Observer Pattern - Register Observers       ");
            System.out.println(" 5. Wheat Quality Check (Singleton)             ");
            System.out.println(" 6. Flour Processing (Template Method)          ");
            System.out.println(" 7. Distribution Management                     ");
            System.out.println(" 8. Exit System                                 ");
            System.out.print("Select an option (1-8): ");

            String choice = scanner.nextLine();

            switch (choice) {
                case "1":
                    manageCompanies();
                    break;
                case "2":
                    demonstrateFactoryPattern();
                    break;
                case "3":
                    demonstrateIteratorPattern();
                    break;
                case "4":
                    demonstrateObserverPattern();
                    break;
                case "5":
                    demonstrateSingletonPattern();
                    break;
                case "6":
                    demonstrateTemplateMethod();
                    break;
                case "7":
                    demonstrateDistribution();
                    break;
                case "8":
                    running = false;
                    System.out.println("\n✓ Thank you for using Egyptian Wheat Tracking System. Goodbye!");
                    break;
                default:
                    System.out.println(" Invalid option. Please try again.");
            }
        }

        scanner.close();
    }

    // 1. COMPANY MANAGEMENT
    private static void manageCompanies() {
        System.out.println("        COMPANY MANAGEMENT SYSTEM              ");

        // Create all company instances
        ArrayList<String> bakeryProducts = new ArrayList<>();
        bakeryProducts.add("Whole Wheat Bread");
        bakeryProducts.add("White Bread");
        bakeryProducts.add("Ciabatta");

        BakeryCompany bakery = new BakeryCompany(
                "Golden Bakery",
                "Cairo, Egypt",
                "Bread",
                500.0,
                400.0,
                bakeryProducts
        );

        MillsCompany mills = new MillsCompany(
                "Egypt Mills Co.",
                "Giza, Egypt",
                "Flour",
                1000.0,
                750.0,
                700.0,
                "Flour 82%"
        );

        SiloCompany silo = new SiloCompany(
                "Silo Storage Center",
                "Alexandria, Egypt",
                "Wheat Storage",
                2000.0,
                1800.0,
                120.0
        );

        ArrayList<String> countries = new ArrayList<>();
        countries.add("Sudan");
        Distrbutioncompany distribution = new Distrbutioncompany(
                "Distribution Hub",
                "Port Said, Egypt",
                "Wheat Distribution",
                5000.0,
                4500.0,
                3000.0,
                countries
        );

        TransportCompany transport = new TransportCompany(
                "Fast Transport Ltd.",
                "Cairo, Egypt",
                "Transportation",
                1500.0,
                1450.0,
                1500.0,
                "Cairo",
                "Alexandria",
                "2 hours"
        );

        PastaFactoryCompany pastaFactory = new PastaFactoryCompany(
                "Italian Pasta Factory",
                "Helwan, Egypt",
                "Pasta",
                800.0,
                700.0,
                "Penna & Spaghetti",
                null
        );

        // Display all companies
        System.out.println("                    REGISTERED COMPANIES                      ");

        displayCompanyInfo(bakery);
        displayCompanyInfo(mills);
        displayCompanyInfo(silo);
        displayCompanyInfo(distribution);
        displayCompanyInfo(transport);
        displayCompanyInfo(pastaFactory);


        // Company-specific checks
        System.out.println("\n--- Company-Specific Operations ---");
        mills.checkWeight(mills.getIncomeWeight(), mills.getOutWeight());
    }

    private static void displayCompanyInfo(Company company) {
        System.out.println("\n Company: " + company.getCompanyName());
        System.out.println("   Address: " + company.getCompanyAddress());
        System.out.println("   Product: " + company.getCompanyProduct());
        System.out.println("   Income Weight: " + company.getIncomeWeight() + " kg");
        System.out.println("   Output Weight: " + company.getOutWeight() + " kg");
    }

    // 2. FACTORY PATTERN DEMONSTRATION
    private static void demonstrateFactoryPattern() {
        System.out.println("     FACTORY PATTERN - PRODUCT CREATION        ");

        SimpelProductFactory factory = new SimpelProductFactory();

        System.out.println("\n--- Available Product Types ---");
        System.out.println("1. Bread Product");
        System.out.println("2. Local Bread Product");
        System.out.println("3. Penna Product");
        System.out.println("4. Spaghetti Product");
        System.out.print("Select product type (1-4): ");

        String productChoice = scanner.nextLine();
        String productType = "";

        switch (productChoice) {
            case "1":
                productType = "Bread Product";
                break;
            case "2":
                productType = "Local Bread Product";
                break;
            case "3":
                productType = "Penna Product";
                break;
            case "4":
                productType = "Spaghteii Product";
                break;
            default:
                System.out.println("Invalid choice");
                return;
        }

        System.out.print("Enter product name: ");
        String name = scanner.nextLine();
        System.out.print("Enter production date (YYYY-MM-DD): ");
        String prodDate = scanner.nextLine();
        System.out.print("Enter expiry date (YYYY-MM-DD): ");
        String expDate = scanner.nextLine();
        System.out.print("Enter product weight (kg): ");
        double weight = Double.parseDouble(scanner.nextLine());
        System.out.print("Enter classification (1-5): ");
        int classification = Integer.parseInt(scanner.nextLine());

        System.out.println("\n✓ Creating product using Factory Pattern...");
        CompanyProduct product = factory.creatproduct(productType);

        if (product != null) {
            System.out.println("        PRODUCT CREATED SUCCESSFULLY    ");
            System.out.println("Type: " + productType);
            System.out.println("Name: " + name);
            System.out.println("Production Date: " + prodDate);
            System.out.println("Expiry Date: " + expDate);
            System.out.println("Weight: " + weight + " kg");
            System.out.println("Classification: " + classification);
        } else {
            System.out.println(" Failed to create product");
        }
    }

    // 3. ITERATOR PATTERN DEMONSTRATION
    private static void demonstrateIteratorPattern() {
        System.out.println("    ITERATOR PATTERN - TRANSPORT METHODS        ");

        TransportCompany transport = new TransportCompany(
                "Fast Transport Ltd.",
                "Cairo, Egypt",
                "Transportation",
                1500.0,
                1450.0,
                1500.0,
                "Cairo",
                "Alexandria",
                "2 hours"
        );

        System.out.println("\n Transport Company: " + transport.getCompanyName());
        System.out.println("From: " + transport.getLocationFrom() + " → To: " + transport.getLocatonTo());
        System.out.println("Weight: " + transport.getWeightTransport() + " kg");
        System.out.println("Estimated Time: " + transport.getEstimatedTimeTransport());

        System.out.println("\n--- Iterating Through Available Transport Methods ---");
        transport.printAllMethods();
    }

    // 4. OBSERVER PATTERN DEMONSTRATION
    private static void demonstrateObserverPattern() {
        System.out.println("      OBSERVER PATTERN - NOTIFICATION SYSTEM   ");

        // Create companies (observers)
        ArrayList<String> bakeryProducts = new ArrayList<>();
        bakeryProducts.add("Bread");
        BakeryCompany bakery = new BakeryCompany(
                "Golden Bakery", "Cairo", "Bread", 500, 400, bakeryProducts
        );

        MillsCompany mills = new MillsCompany(
                "Egypt Mills", "Giza", "Flour", 1000, 750, 700, "Flour 82%"
        );

        SiloCompany silo = new SiloCompany(
                "Silo Storage", "Alexandria", "Storage", 2000, 1800, 120
        );

        // Create transport company (subject)
        TransportCompany transport = new TransportCompany(
                "Fast Transport",
                "Cairo",
                "Transport",
                1500, 1450, 1500,
                "Cairo", "Alexandria", "2 hours"
        );

        System.out.println("\n--- Registering Observers ---");
        transport.registerObserver(bakery);
        transport.registerObserver(mills);
        transport.registerObserver(silo);

        System.out.println("\n--- Sending Notifications to All Observers ---");
        transport.notifyObservers();

        System.out.println("\n--- Removing Bakery Observer ---");
        transport.removeObserver(bakery);

        System.out.println("\n--- Sending Notifications Again ---");
        transport.notifyObservers();
    }

    // 5. SINGLETON PATTERN DEMONSTRATION
    private static void demonstrateSingletonPattern() {
        System.out.println("  SINGLETON PATTERN - WHEAT QUALITY CHECK      ");

        // Get singleton instance
        CheckWheat checker = CheckWheat.getInstance();

        System.out.print("\nEnter total wheat amount (kg) to check: ");
        double wheatAmount = Double.parseDouble(scanner.nextLine());

        System.out.println("\n--- Starting Wheat Quality Check ---");
        checker.checkWheat(wheatAmount);

        System.out.println("\n--- Quality Assessment Results ---");
        System.out.printf("Quality Grade: %s%n", checker.getQualityGrade());
        System.out.printf("Classification Score: %d/100%n", checker.getClassificationScore());
        System.out.printf("Accepted Weight: %.2f kg%n", checker.getAcceptedWeight());
        System.out.printf("Rejected Weight: %.2f kg%n", checker.getRejectedWeight());
        System.out.printf("Flour Yield: %.2f kg%n", checker.getFlourYield());
        System.out.printf("Weight Loss: %.2f%%%n", checker.getWeightLossPercentage());
    }

    // 6. TEMPLATE METHOD PATTERN DEMONSTRATION
    private static void demonstrateTemplateMethod() {
        System.out.println("   TEMPLATE METHOD PATTERN - FLOUR PROCESSING   ");
        System.out.println("\n--- Select Flour Type ---");
        System.out.println("1. Flour 72% (Standard)");
        System.out.println("2. Flour 82% (Medium)");
        System.out.println("3. Flour 92% (Premium)");
        System.out.print("Select flour type (1-3): ");

        String flourChoice = scanner.nextLine();
        FlourTypes flour = null;

        switch (flourChoice) {
            case "1":
                flour = new Flour72();
                break;
            case "2":
                flour = new Flour82();
                break;
            case "3":
                flour = new Flour92();
                break;
            default:
                System.out.println("Invalid choice");
                return;
        }

        System.out.println("\n--- Starting Flour Processing (Template Method) ---");
        flour.processFlour();
    }

    // 7. DISTRIBUTION MANAGEMENT
    private static void demonstrateDistribution() {
        System.out.println("         DISTRIBUTION MANAGEMENT SYSTEM         ");

        ArrayList<String> countries = new ArrayList<>();
        countries.add("Sudan");
        countries.add("Libya");

        Distrbutioncompany distribution = new Distrbutioncompany(
                "Distribution Hub",
                "Port Said, Egypt",
                "Wheat Distribution",
                10000.0,
                9500.0,
                8000.0,
                countries
        );

        System.out.println("\n Distribution Company: " + distribution.getCompanyName());
        System.out.println("Address: " + distribution.getCompanyAddress());
        System.out.println("Total Wheat Available: " + distribution.getTotalWheat() + " kg");
        System.out.println("Countries: " + distribution.getCountries());

        System.out.print("\nEnter destination country: ");
        String country = scanner.nextLine();
        System.out.print("Enter wheat amount to assign (kg): ");
        double amount = Double.parseDouble(scanner.nextLine());

        distribution.AssingnToPlace(country, amount);

        System.out.println("\nRemaining wheat: " + distribution.getTotalWheat() + " kg");
    }
}